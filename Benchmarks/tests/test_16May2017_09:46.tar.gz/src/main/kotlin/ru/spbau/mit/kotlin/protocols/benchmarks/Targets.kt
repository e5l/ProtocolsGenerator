package ru.spbau.mit.kotlin.protocols.benchmarks

protocol interface Bar {
    fun foo()
}

class A0 { fun foo() {} }
class A1 { fun foo() {} }
class A2 { fun foo() {} }
class A3 { fun foo() {} }
class A4 { fun foo() {} }
class A5 { fun foo() {} }
class A6 { fun foo() {} }
class A7 { fun foo() {} }
class A8 { fun foo() {} }
class A9 { fun foo() {} }
class A10 { fun foo() {} }
class A11 { fun foo() {} }
class A12 { fun foo() {} }
class A13 { fun foo() {} }
class A14 { fun foo() {} }
class A15 { fun foo() {} }
class A16 { fun foo() {} }
class A17 { fun foo() {} }
class A18 { fun foo() {} }
class A19 { fun foo() {} }

