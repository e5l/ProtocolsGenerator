package ru.spbau.mit.protocols.benchmarks.testclasses;

public interface FooInterface {
    void bar();
}
