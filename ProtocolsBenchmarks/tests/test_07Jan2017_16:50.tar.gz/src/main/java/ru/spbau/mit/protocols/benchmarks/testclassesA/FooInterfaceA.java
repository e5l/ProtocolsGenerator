package ru.spbau.mit.protocols.benchmarks.testclassesA;

public interface FooInterfaceA {
    void bar();
}
