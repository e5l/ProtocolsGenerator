package ru.spbau.mit.protocols.benchmarks;

public class Foo {
    public void bar() {
    }
}
