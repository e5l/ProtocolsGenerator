package ru.spbau.mit.protocols.benchmarks.testclassesB;

public interface FooInterfaceB {
    void bar();
}
